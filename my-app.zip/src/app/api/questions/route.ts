import { NextResponse } from "next/server";

import {
  BASEQUERY_CONTRACT_ABI,
  BASEQUERY_CONTRACT_ADDRESS,
} from "@/lib/constants";
import { publicClient } from "@/lib/viemConfig";
import { QuestionItem } from "@/types/Question.type";

export async function GET() {
  try {
    const data = await publicClient.readContract({
      address: BASEQUERY_CONTRACT_ADDRESS,
      abi: BASEQUERY_CONTRACT_ABI,
      functionName: "getAllQuestions",
    });
    const [questionIds, ipfsHashes] = data as [
      readonly bigint[],
      readonly string[]
    ];
    const questions = await Promise.all(
      questionIds.map(async (id, idx) => {
        const ipfsHash = ipfsHashes[idx];
        let title: string | undefined;
        let content: string | undefined;
        let tags: string[] | undefined;
        try {
          // If stored value is already a full URL, use it; otherwise, build a gateway URL
          const url = ipfsHash.startsWith("http")
            ? ipfsHash
            : `https://gateway.pinata.cloud/ipfs/${ipfsHash}`;
          const res = await fetch(url, { cache: "no-store" });
          if (res.ok) {
            const json = (await res.json()) as QuestionItem;
            title = json?.title;
            content = json?.content;
            tags = Array.isArray(json?.tags) ? json.tags : undefined;
          }
        } catch (e) {
          // Swallow per-item errors; include fallback fields
        }
        return {
          id: Number(id),
          title,
          content,
          tags,
        };
      })
    );
    // console.log(questions);
    return NextResponse.json({ questions });
  } catch (error) {
    console.error("Error fetching questions:", error);
    return NextResponse.json(
      { error: "Failed to fetch questions" },
      { status: 500 }
    );
  }
}
