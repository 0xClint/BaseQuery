import React from "react";

export default function Footer() {
  return (
    <footer className="bg-main text-center border-t border-border py-3 px-4 sm:px-6 lg:px-8">
     Made with love!
    </footer>
  );
}
