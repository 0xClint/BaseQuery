export type QuestionItem = {
  id?: string | number;
  title: string;
  content: string;
  tags: string[];
};

export type AnwserItem = {
  id?: string | number;
  content: string;
  upvote: number;
  downvote: number;
  tags: string[];
};

export type IndexerQuestion = {
  id: string;
  tags?: string[];
  owner: string;
  poolAmount: string;
  poolEndTime: string;
  questionId: string;
  transactionHash: string;
};
